package com.cg.empSystem.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;




import oracle.jdbc.pool.OracleDataSource;

import com.cg.empSystem.exception.EmployeeException;

public class DBUtil {
	/*private DataSource datasource;

	public DBUtil() throws EmployeeException {
		try {
			Context ctx = new InitialContext(); //get reference to remote JNDI
			datasource  = (DataSource) ctx.lookup("java:/OracleDS2");
		} catch (NamingException e) {
			e.printStackTrace();
			throw new EmployeeException("failed to get JNDI Context",e);
		}
	}
	
	public Connection getConnection() throws SQLException{
		return datasource.getConnection();
	}
	*/
	
	
	
	private OracleDataSource dataSource;
	   public DBUtil(){
			try {
				dataSource=new OracleDataSource();
				dataSource.setURL("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G");
				dataSource.setUser("labg104trg20");
				dataSource.setPassword("labg104oracle");
				dataSource.setDriverType("oracle");
				
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		public Connection getConnection() throws SQLException{
			return dataSource.getConnection();
		}

		@Override
		protected void finalize() throws Throwable {
			dataSource.close();
			super.finalize();
		}
		
		
	
}
