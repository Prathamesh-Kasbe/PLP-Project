package com.cg.empSystem.tests;



import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.empSystem.dao.EmployeeDao;
import com.cg.empSystem.dao.EmployeeDaoImpl;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;

public class TestsAddEmployeeDetails {

	EmployeeDao dao;
	Employee employee;
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		
		dao = new EmployeeDaoImpl();
		employee = new Employee("100010", null, null, null, null, 1010, null, null, "M3", null, null, null, null);
		
	}
	
	@After
	public void teardown() throws Exception {
		
		dao = null;
		employee=null;
		
	}

	@Test
	public void testAddEmployeeDetails() throws EmployeeException {
		equals(dao.addEmployeeDetails(employee));
	}

}
