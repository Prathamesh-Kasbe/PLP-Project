package com.cg.empSystem.tests;

import java.sql.Date;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.exception.EmployeeException;
import com.cg.empSystem.service.EmployeeService;
import com.cg.empSystem.service.EmployeeServiceImpl;

public class TestSrchEmpOnMrStatus {
	EmployeeService empService = null;
	Grade grade = null;

	@Before
	public void setUp() throws EmployeeException {
		empService = new EmployeeServiceImpl();
		
	}

	@After
	public void tearDown() throws EmployeeException {
		empService= null;
		grade = null;
	}

	@Test
	public void test() throws EmployeeException{
		
	}


}
