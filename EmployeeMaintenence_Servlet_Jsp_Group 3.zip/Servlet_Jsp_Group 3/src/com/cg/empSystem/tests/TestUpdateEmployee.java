package com.cg.empSystem.tests;



import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.empSystem.dao.EmployeeDao;
import com.cg.empSystem.dao.EmployeeDaoImpl;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;

public class TestUpdateEmployee {


	EmployeeDao dao;
	Employee employee;
	
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	
		dao = new EmployeeDaoImpl();
		employee= new Employee("100001", null, null, null, null, 0, null, null, 0, null, null, null, null);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testUpdateEmployee() throws EmployeeException {
	assertNotNull(dao.updateEmployee(employee));
	}

}
